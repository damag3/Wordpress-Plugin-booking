<?php
/**
 * Surf Booking Form Submission & Email Handler
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Surf_Booking_Handler {
    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'wp_ajax_submit_surf_booking', array( $this, 'handle_booking_submission' ) );
        add_action( 'wp_ajax_nopriv_submit_surf_booking', array( $this, 'handle_booking_submission' ) );
    }

    /**
     * Handle AJAX Form Submission
     */
    public function handle_booking_submission() {
        // Verify Nonce
        if ( ! isset( $_POST['security'] ) || ! wp_verify_nonce( $_POST['security'], 'surf_booking_nonce_action' ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed. Please refresh the page and try again.' ) );
        }

        // Validate Required Fields
        if ( empty( $_POST['name'] ) || empty( $_POST['email'] ) || empty( $_POST['level'] ) || empty( $_POST['date'] ) || empty( $_POST['time'] ) ) {
            wp_send_json_error( array( 'message' => 'Please fill in all required fields.' ) );
        }

        // Sanitize Input Data
        $name     = sanitize_text_field( $_POST['name'] );
        $email    = sanitize_email( $_POST['email'] );
        $phone    = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
        $level    = sanitize_text_field( $_POST['level'] );
        $date     = sanitize_text_field( $_POST['date'] );
        $time     = sanitize_text_field( $_POST['time'] );
        $comments = isset( $_POST['comments'] ) ? sanitize_textarea_field( $_POST['comments'] ) : '';

        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => 'Please provide a valid email address.' ) );
        }

        // Create the Surf Booking CPT Post
        $booking_id = wp_insert_post( array(
            'post_title'   => $name,
            'post_content' => $comments,
            'post_status'  => 'sb_pending',
            'post_type'    => 'surf_booking',
        ) );

        if ( is_wp_error( $booking_id ) || ! $booking_id ) {
            wp_send_json_error( array( 'message' => 'Failed to save your booking. Please try again.' ) );
        }

        // Generate Secure One-Time Token
        $secure_token = wp_generate_password( 32, false );

        // Save Metadata
        update_post_meta( $booking_id, '_sb_booking_date', $date );
        update_post_meta( $booking_id, '_sb_booking_time', $time );
        update_post_meta( $booking_id, '_sb_surf_level', $level );
        update_post_meta( $booking_id, '_sb_customer_email', $email );
        update_post_meta( $booking_id, '_sb_customer_phone', $phone );
        update_post_meta( $booking_id, '_sb_secure_token', $secure_token );

        // Send Email to Instructor
        $mail_sent = $this->send_instructor_email( $booking_id, $name, $email, $phone, $level, $date, $time, $comments, $secure_token );

        if ( $mail_sent ) {
            wp_send_json_success( array(
                'message' => 'Your surf lesson request has been submitted successfully! It is currently pending approval. We will contact you soon. Please check your spam folder if you do not see our reply.'
            ) );
        } else {
            // Log error internally, but let customer know booking is recorded
            error_log( 'Ericeira Surf Booking: Failed to send email to instructor for booking ID: ' . $booking_id );
            wp_send_json_success( array(
                'message' => 'Your booking request has been saved! (Notification email encountered a delay, but your request is secure).'
            ) );
        }
    }

    /**
     * Send HTML Email Notification to Instructor
     */
    private function send_instructor_email( $booking_id, $name, $email, $phone, $level, $date, $time, $comments, $secure_token ) {
        // Retrieve Instructor Email
        $instructor_email = get_option( 'surf_booking_instructor_email', 'ericeiralocal@gmail.com' );

        // Construct Approve and Reject Links using REST API
        $approve_url = add_query_arg( array(
            'id'     => $booking_id,
            'token'  => $secure_token,
            'action' => 'approve',
        ), get_rest_url( null, '/surf-booking/v1/action' ) );

        $reject_url = add_query_arg( array(
            'id'     => $booking_id,
            'token'  => $secure_token,
            'action' => 'reject',
        ), get_rest_url( null, '/surf-booking/v1/action' ) );

        // Map Surf Levels for Email Display
        $levels_map = array(
            'first_lesson' => 'First Lesson (1ª Aula)',
            'beginner'     => 'Beginner (Iniciado)',
            'intermediate' => 'Intermediate (Intermédio)',
            'advanced'     => 'Advanced (Avançado)',
        );
        $level_display = isset( $levels_map[ $level ] ) ? $levels_map[ $level ] : $level;
        $formatted_date = date_i18n( 'l, F j, Y', strtotime( $date ) );

        // Prepare Template Variables by setting them in context for output buffering
        $template_args = array(
            'booking_id'    => $booking_id,
            'name'          => $name,
            'email'         => $email,
            'phone'         => $phone,
            'level'         => $level_display,
            'date'          => $formatted_date,
            'time'          => $time,
            'comments'      => $comments,
            'approve_url'   => $approve_url,
            'reject_url'    => $reject_url,
        );

        // Load Email Template
        ob_start();
        extract( $template_args );
        include SURF_BOOKING_PATH . 'templates/email-instructor.php';
        $message_html = ob_get_clean();

        // Email Headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Ericeira Local Surf <' . get_option( 'admin_email' ) . '>',
            'Reply-To: ' . $name . ' <' . $email . '>'
        );

        $subject = '🌊 Novo Pedido de Aula de Surf - ' . $name;

        // Send using wp_mail
        return wp_mail( $instructor_email, $subject, $message_html, $headers );
    }
}
