<?php
/**
 * Surf Booking REST API Action Router
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Surf_Booking_API {
    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
    }

    /**
     * Register Custom REST Routes
     */
    public function register_rest_routes() {
        register_rest_route( 'surf-booking/v1', '/action', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'handle_action_request' ),
            'permission_callback' => '__return_true', // Publicly accessible via secure token
        ) );
    }

    /**
     * Handle Action Request (Approve/Reject)
     */
    public function handle_action_request( $request ) {
        $booking_id = intval( $request->get_param( 'id' ) );
        $token      = sanitize_text_field( $request->get_param( 'token' ) );
        $action     = sanitize_text_field( $request->get_param( 'action' ) );

        // Validate basic inputs
        if ( ! $booking_id || ! $token || ! in_array( $action, array( 'approve', 'reject' ) ) ) {
            $this->render_feedback_page( false, 'Pedido Inválido', 'Os parâmetros do pedido estão em falta ou são incorretos.' );
        }

        // Fetch Booking Post
        $post = get_post( $booking_id );
        if ( ! $post || $post->post_type !== 'surf_booking' ) {
            $this->render_feedback_page( false, 'Reserva Não Encontrada', 'A reserva de surf solicitada não existe.' );
        }

        // Validate Secure Token
        $stored_token = get_post_meta( $booking_id, '_sb_secure_token', true );
        if ( empty( $stored_token ) || $stored_token !== $token ) {
            $this->render_feedback_page( false, 'Acesso Não Autorizado', 'A validação de segurança falhou. O acesso não é autorizado.' );
        }

        // Map status
        $status_map = array(
            'approve' => 'sb_approved',
            'reject'  => 'sb_rejected',
        );
        $new_status = $status_map[ $action ];

        // Check if status is already updated
        $current_status = $post->post_status;
        if ( $current_status === $new_status ) {
            $status_label = ( $action === 'approve' ) ? 'Aprovada' : 'Recusada';
            $this->render_feedback_page( true, "Já Processada", "Esta reserva já foi processada anteriormente como $status_label.", $booking_id );
        }

        // Update post status
        $update_result = wp_update_post( array(
            'ID'          => $booking_id,
            'post_status' => $new_status,
        ) );

        if ( is_wp_error( $update_result ) ) {
            $this->render_feedback_page( false, 'Erro de Sistema', 'Não foi possível atualizar o estado da reserva. Por favor, tente novamente.' );
        }

        // Send confirmation email to customer
        $this->notify_customer( $booking_id, $action );

        // Render success page
        $title   = ( $action === 'approve' ) ? 'Reserva Aprovada!' : 'Reserva Recusada';
        $message = ( $action === 'approve' ) 
            ? 'A aula de surf foi aprovada. O cliente foi notificado por e-mail.' 
            : 'O pedido de reserva foi recusado. O cliente foi notificado por e-mail.';

        $this->render_feedback_page( true, $title, $message, $booking_id );
    }

    /**
     * Render the Custom Action Feedback UI
     */
    private function render_feedback_page( $success, $title, $message, $booking_id = 0 ) {
        // Retrieve booking details for summary box
        $details = array();
        if ( $booking_id ) {
            $date = get_post_meta( $booking_id, '_sb_booking_date', true );
            $time = get_post_meta( $booking_id, '_sb_booking_time', true );
            $level = get_post_meta( $booking_id, '_sb_surf_level', true );
            $email = get_post_meta( $booking_id, '_sb_customer_email', true );
            $name = get_the_title( $booking_id );

            $levels_map = array(
                'first_lesson' => 'First Lesson',
                'beginner'     => 'Beginner',
                'intermediate' => 'Intermediate',
                'advanced'     => 'Advanced',
            );

            $details = array(
                'name'  => $name,
                'email' => $email,
                'date'  => $date ? date_i18n( 'l, F j, Y', strtotime( $date ) ) : '—',
                'time'  => $time ? $time : '—',
                'level' => isset( $levels_map[ $level ] ) ? $levels_map[ $level ] : $level,
            );
        }

        header( 'Content-Type: text/html; charset=utf-8' );
        
        // Pass variables to template
        $template_args = array(
            'success'      => $success,
            'title'        => $title,
            'message'      => $message,
            'booking_id'   => $booking_id,
            'details'      => $details,
        );

        extract( $template_args );
        include SURF_BOOKING_PATH . 'templates/action-feedback.php';
        exit;
    }

    /**
     * Send email notification to customer
     */
    private function notify_customer( $booking_id, $action ) {
        $customer_email = get_post_meta( $booking_id, '_sb_customer_email', true );
        $customer_name  = get_the_title( $booking_id );
        $date           = get_post_meta( $booking_id, '_sb_booking_date', true );
        $time           = get_post_meta( $booking_id, '_sb_booking_time', true );
        $formatted_date = date_i18n( 'l, F j, Y', strtotime( $date ) );

        if ( ! $customer_email ) {
            return;
        }

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Ericeira Local Surf <ericeiralocal@gmail.com>',
            'Reply-To: ericeiralocal@gmail.com'
        );

        if ( 'approve' === $action ) {
            $subject = '🏄 Surf Lesson Confirmed - Ericeira Local Surf';
            $body = "
                <!DOCTYPE html>
                <html>
                <head><meta charset='utf-8'></head>
                <body style='margin:0; padding:0; background-color:#f8fafc; font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;'>
                    <table width='100%' border='0' cellpadding='0' cellspacing='0' style='background-color:#f8fafc; padding:30px 15px;'>
                        <tr>
                            <td align='center'>
                                <table width='100%' style='max-width:550px; background-color:#ffffff; border-radius:12px; overflow:hidden; border:1px solid #e2e8f0; box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);'>
                                    <tr>
                                        <td style='background:#0ea5e9; padding:20px; text-align:center;'>
                                            <h2 style='color:#ffffff; margin:0; font-size:20px;'>Aloha $customer_name!</h2>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style='padding:30px; font-size:15px; color:#334155; line-height:1.6;'>
                                            <p style='margin-top:0;'>Awesome news! Your surf lesson booking at <strong>Ericeira Local Surf</strong> has been <strong>confirmed</strong> by the instructor.</p>
                                            <div style='background:#f1f5f9; padding:15px; border-radius:8px; margin:20px 0;'>
                                                <table width='100%'>
                                                    <tr><td style='color:#64748b; font-size:13px;'><strong>Date:</strong></td><td style='color:#0f172a; text-align:right;'><strong>$formatted_date</strong></td></tr>
                                                    <tr><td style='color:#64748b; font-size:13px;'><strong>Time:</strong></td><td style='color:#0f172a; text-align:right;'><strong>$time</strong></td></tr>
                                                </table>
                                            </div>
                                            <p>Please make sure to arrive 15 minutes before the scheduled time. We will provide all surf gear (wetsuit and board).</p>
                                            <p style='margin-bottom:0;'>If you need to change or cancel your booking, please reply directly to this email or contact us at <a href='mailto:ericeiralocal@gmail.com' style='color:#0ea5e9; text-decoration:none;'>ericeiralocal@gmail.com</a>.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style='background:#f8fafc; padding:15px; text-align:center; font-size:12px; color:#94a3b8; border-top:1px solid #f1f5f9;'>
                                            Ericeira Local Surf &bull; World Surfing Reserve
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
            ";
        } else {
            $subject = '✉️ Surf Lesson Request - Ericeira Local Surf';
            $body = "
                <!DOCTYPE html>
                <html>
                <head><meta charset='utf-8'></head>
                <body style='margin:0; padding:0; background-color:#f8fafc; font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;'>
                    <table width='100%' border='0' cellpadding='0' cellspacing='0' style='background-color:#f8fafc; padding:30px 15px;'>
                        <tr>
                            <td align='center'>
                                <table width='100%' style='max-width:550px; background-color:#ffffff; border-radius:12px; overflow:hidden; border:1px solid #e2e8f0; box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);'>
                                    <tr>
                                        <td style='background:#f43f5e; padding:20px; text-align:center;'>
                                            <h2 style='color:#ffffff; margin:0; font-size:20px;'>Hello $customer_name,</h2>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style='padding:30px; font-size:15px; color:#334155; line-height:1.6;'>
                                            <p style='margin-top:0;'>Thank you for requesting a surf lesson at <strong>Ericeira Local Surf</strong>.</p>
                                            <p>Unfortunately, we are unable to schedule your lesson on <strong>$formatted_date</strong> at <strong>$time</strong> because of scheduling conflicts or adverse wave/tide forecasts.</p>
                                            <p>We would love to get you in the water on another day. Please contact us at <a href='mailto:ericeiralocal@gmail.com' style='color:#0ea5e9; text-decoration:none;'>ericeiralocal@gmail.com</a> or reply directly to this email to reschedule.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style='background:#f8fafc; padding:15px; text-align:center; font-size:12px; color:#94a3b8; border-top:1px solid #f1f5f9;'>
                                            Ericeira Local Surf &bull; World Surfing Reserve
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
            ";
        }

        wp_mail( $customer_email, $subject, $body, $headers );
    }
}
