<?php
/**
 * Surf Booking Admin Settings Page
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Surf_Booking_Settings {
    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    /**
     * Add settings submenu under Settings
     */
    public function add_settings_menu() {
        add_options_page(
            __( 'Surf Booking Settings', 'ericeira-surf-booking' ),
            __( 'Surf Booking', 'ericeira-surf-booking' ),
            'manage_options',
            'surf-booking-settings',
            array( $this, 'render_settings_page' )
        );
    }

    /**
     * Register Plugin Settings
     */
    public function register_settings() {
        register_setting( 'surf_booking_settings_group', 'surf_booking_instructor_email', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default'           => 'ericeiralocal@gmail.com',
        ) );

        add_settings_section(
            'surf_booking_general_section',
            __( 'General Settings', 'ericeira-surf-booking' ),
            array( $this, 'section_description' ),
            'surf-booking-settings'
        );

        add_settings_field(
            'surf_booking_instructor_email_field',
            __( 'Instructor Gmail Address', 'ericeira-surf-booking' ),
            array( $this, 'email_field_callback' ),
            'surf-booking-settings',
            'surf_booking_general_section'
        );
    }

    /**
     * Section Description
     */
    public function section_description() {
        echo '<p>' . esc_html__( 'Configure the email notification settings for Ericeira Local Surf.', 'ericeira-surf-booking' ) . '</p>';
    }

    /**
     * Email Field Callback
     */
    public function email_field_callback() {
        $email = get_option( 'surf_booking_instructor_email', 'ericeiralocal@gmail.com' );
        echo '<input type="email" name="surf_booking_instructor_email" value="' . esc_attr( $email ) . '" class="regular-text" required />';
        echo '<p class="description">' . esc_html__( 'This Gmail address will receive the lesson requests with approval and rejection links.', 'ericeira-surf-booking' ) . '</p>';
    }

    /**
     * Render the Settings Page HTML
     */
    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields( 'surf_booking_settings_group' );
                do_settings_sections( 'surf-booking-settings' );
                submit_button();
                ?>
            </form>
            <div style="margin-top: 30px; padding: 15px; background: #fff; border-left: 4px solid #1d2327; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h2><?php esc_html_e( 'How to Use', 'ericeira-surf-booking' ); ?></h2>
                <p><?php printf( __( 'To display the booking form on any page, use the following shortcode: %s', 'ericeira-surf-booking' ), '<code>[surf_booking_form]</code>' ); ?></p>
            </div>
        </div>
        <?php
    }
}
