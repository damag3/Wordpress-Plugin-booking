<?php
/**
 * Surf Booking Custom Post Type Registry
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Surf_Booking_CPT {
    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'init', array( $this, 'register_cpt' ) );
        add_action( 'init', array( $this, 'register_custom_statuses' ) );
        
        // Admin column customization
        add_filter( 'manage_surf_booking_posts_columns', array( $this, 'add_custom_columns' ) );
        add_action( 'manage_surf_booking_posts_custom_column', array( $this, 'render_custom_columns' ), 10, 2 );
        add_filter( 'manage_edit-surf_booking_sortable_columns', array( $this, 'register_sortable_columns' ) );
        add_action( 'pre_get_posts', array( $this, 'sort_custom_columns' ) );
    }

    /**
     * Register the Custom Post Type.
     */
    public function register_cpt() {
        $labels = array(
            'name'                  => _x( 'Surf Bookings', 'Post Type General Name', 'ericeira-surf-booking' ),
            'singular_name'         => _x( 'Surf Booking', 'Post Type Singular Name', 'ericeira-surf-booking' ),
            'menu_name'             => __( 'Surf Bookings', 'ericeira-surf-booking' ),
            'name_admin_bar'        => __( 'Surf Booking', 'ericeira-surf-booking' ),
            'archives'              => __( 'Booking Archives', 'ericeira-surf-booking' ),
            'attributes'            => __( 'Booking Attributes', 'ericeira-surf-booking' ),
            'parent_item_colon'     => __( 'Parent Booking:', 'ericeira-surf-booking' ),
            'all_items'             => __( 'All Bookings', 'ericeira-surf-booking' ),
            'add_new_item'          => __( 'Add New Booking', 'ericeira-surf-booking' ),
            'add_new'               => __( 'Add New', 'ericeira-surf-booking' ),
            'new_item'              => __( 'New Booking', 'ericeira-surf-booking' ),
            'edit_item'             => __( 'Edit Booking', 'ericeira-surf-booking' ),
            'update_item'           => __( 'Update Booking', 'ericeira-surf-booking' ),
            'view_item'             => __( 'View Booking', 'ericeira-surf-booking' ),
            'view_items'            => __( 'View Bookings', 'ericeira-surf-booking' ),
            'search_items'          => __( 'Search Bookings', 'ericeira-surf-booking' ),
            'not_found'             => __( 'No bookings found.', 'ericeira-surf-booking' ),
            'not_found_in_trash'    => __( 'No bookings found in Trash.', 'ericeira-surf-booking' ),
            'featured_image'        => __( 'Featured Image', 'ericeira-surf-booking' ),
            'set_featured_image'    => __( 'Set featured image', 'ericeira-surf-booking' ),
            'remove_featured_image' => __( 'Remove featured image', 'ericeira-surf-booking' ),
            'use_featured_image'    => __( 'Use as featured image', 'ericeira-surf-booking' ),
            'insert_into_item'      => __( 'Insert into booking', 'ericeira-surf-booking' ),
            'uploaded_to_this_item' => __( 'Uploaded to this booking', 'ericeira-surf-booking' ),
            'items_list'            => __( 'Bookings list', 'ericeira-surf-booking' ),
            'items_list_navigation' => __( 'Bookings list navigation', 'ericeira-surf-booking' ),
            'filter_items_list'     => __( 'Filter bookings list', 'ericeira-surf-booking' ),
        );

        $args = array(
            'label'                 => __( 'Surf Booking', 'ericeira-surf-booking' ),
            'description'           => __( 'Surf Lesson Bookings', 'ericeira-surf-booking' ),
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor' ),
            'hierarchical'          => false,
            'public'                => false,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 25,
            'menu_icon'             => 'dashicons-calendar-alt',
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'post',
            'show_in_rest'          => false,
        );

        register_post_type( 'surf_booking', $args );
    }

    /**
     * Register Custom Post Statuses for Bookings
     */
    public function register_custom_statuses() {
        // Pending Status
        register_post_status( 'sb_pending', array(
            'label'                     => _x( 'Pending', 'post status', 'ericeira-surf-booking' ),
            'public'                    => true,
            'exclude_from_search'       => true,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Pending <span class="count">(%s)</span>', 'Pending <span class="count">(%s)</span>', 'ericeira-surf-booking' ),
        ) );

        // Approved Status
        register_post_status( 'sb_approved', array(
            'label'                     => _x( 'Approved', 'post status', 'ericeira-surf-booking' ),
            'public'                    => true,
            'exclude_from_search'       => true,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Approved <span class="count">(%s)</span>', 'Approved <span class="count">(%s)</span>', 'ericeira-surf-booking' ),
        ) );

        // Rejected Status
        register_post_status( 'sb_rejected', array(
            'label'                     => _x( 'Rejected', 'post status', 'ericeira-surf-booking' ),
            'public'                    => true,
            'exclude_from_search'       => true,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( 'Rejected <span class="count">(%s)</span>', 'Rejected <span class="count">(%s)</span>', 'ericeira-surf-booking' ),
        ) );
    }

    /**
     * Add Custom Admin Columns
     */
    public function add_custom_columns( $columns ) {
        $new_columns = array(
            'cb'                => $columns['cb'],
            'title'             => __( 'Customer Name', 'ericeira-surf-booking' ),
            'booking_date_time' => __( 'Date & Time', 'ericeira-surf-booking' ),
            'surf_level'        => __( 'Surf Level', 'ericeira-surf-booking' ),
            'customer_email'    => __( 'Email', 'ericeira-surf-booking' ),
            'customer_phone'    => __( 'Phone', 'ericeira-surf-booking' ),
            'booking_status'    => __( 'Status', 'ericeira-surf-booking' ),
        );
        return $new_columns;
    }

    /**
     * Render Custom Admin Column Content
     */
    public function render_custom_columns( $column, $post_id ) {
        switch ( $column ) {
            case 'booking_date_time':
                $date = get_post_meta( $post_id, '_sb_booking_date', true );
                $time = get_post_meta( $post_id, '_sb_booking_time', true );
                
                if ( $date ) {
                    $formatted_date = date_i18n( get_option( 'date_format' ), strtotime( $date ) );
                    echo esc_html( $formatted_date ) . ' @ ' . esc_html( $time );
                } else {
                    echo '—';
                }
                break;

            case 'surf_level':
                $level = get_post_meta( $post_id, '_sb_surf_level', true );
                $levels_map = array(
                    'first_lesson' => '1st Lesson',
                    'beginner'     => 'Beginner',
                    'intermediate' => 'Intermediate',
                    'advanced'     => 'Advanced',
                );
                echo esc_html( isset( $levels_map[ $level ] ) ? $levels_map[ $level ] : $level );
                break;

            case 'customer_email':
                $email = get_post_meta( $post_id, '_sb_customer_email', true );
                if ( $email ) {
                    echo '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>';
                } else {
                    echo '—';
                }
                break;

            case 'customer_phone':
                $phone = get_post_meta( $post_id, '_sb_customer_phone', true );
                echo $phone ? esc_html( $phone ) : '—';
                break;

            case 'booking_status':
                $status = get_post_status( $post_id );
                $status_labels = array(
                    'sb_pending'  => array( 'label' => 'Pending', 'class' => 'sb-status-pending' ),
                    'sb_approved' => array( 'label' => 'Approved', 'class' => 'sb-status-approved' ),
                    'sb_rejected' => array( 'label' => 'Rejected', 'class' => 'sb-status-rejected' ),
                );

                if ( isset( $status_labels[ $status ] ) ) {
                    $info = $status_labels[ $status ];
                    
                    // Simple inline style/class rendering for admin UI
                    $style = '';
                    if ( $status === 'sb_pending' ) {
                        $style = 'background: #fef3c7; color: #d97706; padding: 4px 8px; border-radius: 4px; font-weight: 600; display: inline-block;';
                    } elseif ( $status === 'sb_approved' ) {
                        $style = 'background: #dcfce7; color: #15803d; padding: 4px 8px; border-radius: 4px; font-weight: 600; display: inline-block;';
                    } elseif ( $status === 'sb_rejected' ) {
                        $style = 'background: #fee2e2; color: #b91c1c; padding: 4px 8px; border-radius: 4px; font-weight: 600; display: inline-block;';
                    }

                    echo '<span style="' . esc_attr($style) . '">' . esc_html( $info['label'] ) . '</span>';
                } else {
                    echo esc_html( $status );
                }
                break;
        }
    }

    /**
     * Register Sortable Columns
     */
    public function register_sortable_columns( $columns ) {
        $columns['booking_date_time'] = 'booking_date_time';
        return $columns;
    }

    /**
     * Handle Sortable Column logic
     */
    public function sort_custom_columns( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) {
            return;
        }

        if ( $query->get( 'post_type' ) === 'surf_booking' ) {
            $orderby = $query->get( 'orderby' );

            if ( 'booking_date_time' === $orderby ) {
                $query->set( 'meta_key', '_sb_booking_date' );
                $query->set( 'orderby', 'meta_value' );
            }
        }
    }
}
