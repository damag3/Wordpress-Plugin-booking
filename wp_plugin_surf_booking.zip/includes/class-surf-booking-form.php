<?php
/**
 * Surf Booking Frontend Shortcode Form
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Surf_Booking_Form {
    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_shortcode( 'surf_booking_form', array( $this, 'render_booking_form' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Enqueue Assets
     */
    public function enqueue_assets() {
        // Enqueue Google Font (Inter & Outfit) for premium typography
        wp_enqueue_style( 'surf-booking-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap', array(), SURF_BOOKING_VERSION );

        // Enqueue Styles
        wp_enqueue_style( 'surf-booking-frontend-styles', SURF_BOOKING_URL . 'assets/css/frontend.css', array(), SURF_BOOKING_VERSION );

        // Enqueue Scripts
        wp_enqueue_script( 'surf-booking-frontend-scripts', SURF_BOOKING_URL . 'assets/js/frontend.js', array( 'jquery' ), SURF_BOOKING_VERSION, true );

        // Localize Script for AJAX
        wp_localize_script( 'surf-booking-frontend-scripts', 'surfBookingAjax', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'surf_booking_nonce_action' ),
        ) );
    }

    /**
     * Render the Booking Form
     */
    public function render_booking_form() {
        ob_start();
        ?>
        <div class="esb-booking-container">
            <div class="esb-booking-card">
                <div class="esb-card-header">
                    <span class="esb-badge">Ericeira Local Surf</span>
                    <h2>Book Your Surf Lesson</h2>
                    <p>Select your date, time, and level to catch the perfect wave.</p>
                </div>
                
                <form id="esb-booking-form" class="esb-form">
                    <div class="esb-form-row">
                        <!-- Name -->
                        <div class="esb-form-group">
                            <label for="sb_name">Full Name <span class="esb-required">*</span></label>
                            <div class="esb-input-wrapper">
                                <span class="esb-input-icon">👤</span>
                                <input type="text" id="sb_name" name="sb_name" placeholder="John Doe" required />
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="esb-form-group">
                            <label for="sb_email">Email Address <span class="esb-required">*</span></label>
                            <div class="esb-input-wrapper">
                                <span class="esb-input-icon">✉️</span>
                                <input type="email" id="sb_email" name="sb_email" placeholder="john@example.com" required />
                            </div>
                        </div>
                    </div>

                    <div class="esb-form-row">
                        <!-- Phone Number -->
                        <div class="esb-form-group">
                            <label for="sb_phone">Phone Number <span class="esb-optional">(Optional)</span></label>
                            <div class="esb-phone-wrapper">
                                <select id="sb_country_code" name="sb_country_code" class="esb-country-select">
                                    <option value="+351">🇵🇹 +351 (PT)</option>
                                    <option value="+1">🇺🇸 +1 (US)</option>
                                    <option value="+44">🇬🇧 +44 (UK)</option>
                                    <option value="+34">🇪🇸 +34 (ES)</option>
                                    <option value="+33">🇫🇷 +33 (FR)</option>
                                    <option value="+49">🇩🇪 +49 (DE)</option>
                                    <option value="+31">🇳🇱 +31 (NL)</option>
                                    <option value="+39">🇮🇹 +39 (IT)</option>
                                    <option value="+353">🇮🇪 +353 (IE)</option>
                                    <option value="+61">🇦🇺 +61 (AU)</option>
                                    <option value="+55">🇧🇷 +55 (BR)</option>
                                </select>
                                <input type="tel" id="sb_phone" name="sb_phone" placeholder="912 345 678" />
                            </div>
                        </div>

                        <!-- Surf Level -->
                        <div class="esb-form-group">
                            <label for="sb_surf_level">Surf Level <span class="esb-required">*</span></label>
                            <div class="esb-input-wrapper">
                                <span class="esb-input-icon">🏄</span>
                                <select id="sb_surf_level" name="sb_surf_level" required>
                                    <option value="" disabled selected>Select your skill level</option>
                                    <option value="first_lesson">First Lesson (1ª Aula)</option>
                                    <option value="beginner">Beginner (Iniciado)</option>
                                    <option value="intermediate">Intermediate (Intermédio)</option>
                                    <option value="advanced">Advanced (Avançado)</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="esb-form-row">
                        <!-- Date -->
                        <div class="esb-form-group">
                            <label for="sb_date">Preferred Date <span class="esb-required">*</span></label>
                            <div class="esb-input-wrapper">
                                <span class="esb-input-icon">📅</span>
                                <input type="date" id="sb_date" name="sb_date" required min="<?php echo esc_attr( date( 'Y-m-d' ) ); ?>" />
                            </div>
                        </div>

                        <!-- Time -->
                        <div class="esb-form-group">
                            <label for="sb_time">Preferred Time <span class="esb-required">*</span></label>
                            <div class="esb-input-wrapper">
                                <span class="esb-input-icon">⏰</span>
                                <select id="sb_time" name="sb_time" required>
                                    <option value="" disabled selected>Select a time slot</option>
                                    <option value="08:00">08:00 AM</option>
                                    <option value="09:30">09:30 AM</option>
                                    <option value="11:00">11:00 AM</option>
                                    <option value="13:30">01:30 PM</option>
                                    <option value="15:00">03:00 PM</option>
                                    <option value="16:30">04:30 PM</option>
                                    <option value="18:00">06:00 PM</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Comment -->
                    <div class="esb-form-group">
                        <label for="sb_comments">Comments / Medical Conditions <span class="esb-optional">(Optional)</span></label>
                        <textarea id="sb_comments" name="sb_comments" rows="3" placeholder="Tell us about your surfing experience or any specific requests..."></textarea>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" id="esb-submit-btn" class="esb-submit-btn">
                        <span class="btn-text">Submit Booking Request</span>
                        <span class="btn-loader esb-hidden">
                            <svg class="esb-spinner" viewBox="0 0 50 50">
                                <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
                            </svg>
                        </span>
                    </button>

                    <!-- Spam Warning Notice -->
                    <p class="esb-spam-note">✉️ Please check your spam / junk folder if you don't receive our reply in your inbox.</p>
                    
                    <!-- Feedback Messages -->
                    <div id="esb-feedback" class="esb-feedback esb-hidden"></div>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
