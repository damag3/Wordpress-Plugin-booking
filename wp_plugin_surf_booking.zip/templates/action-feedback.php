<?php
/**
 * Action Feedback UI Template (Stand-alone Landing Page)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Determine status and design classes
$post_status = $booking_id ? get_post_status( $booking_id ) : '';
$card_class = 'rejected';
$icon = '⚠️';

if ( $success ) {
    if ( 'sb_approved' === $post_status ) {
        $card_class = 'approved';
        $icon = '🌊';
    } elseif ( 'sb_rejected' === $post_status ) {
        $card_class = 'rejected';
        $icon = '❌';
    } else {
        $card_class = 'approved';
        $icon = 'ℹ️';
    }
} else {
    $card_class = 'rejected';
    $icon = '❌';
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html( $title ); ?> - Ericeira Local Surf</title>
    <!-- Load fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap">
    <!-- Load Plugin CSS -->
    <link rel="stylesheet" href="<?php echo esc_url( SURF_BOOKING_URL . 'assets/css/frontend.css' ); ?>">
</head>
<body class="esb-action-body">

    <div class="esb-action-card <?php echo esc_attr( $card_class ); ?>">
        <div class="esb-action-icon-wrapper">
            <?php echo esc_html( $icon ); ?>
        </div>
        
        <h1 class="esb-action-title"><?php echo esc_html( $title ); ?></h1>
        <p class="esb-action-message"><?php echo esc_html( $message ); ?></p>
        
        <?php if ( ! empty( $details ) ) : ?>
            <div class="esb-action-details">
                <div class="esb-detail-row">
                    <span class="esb-detail-label">Nome do Cliente</span>
                    <span class="esb-detail-value"><?php echo esc_html( $details['name'] ); ?></span>
                </div>
                <div class="esb-detail-row">
                    <span class="esb-detail-label">E-mail do Cliente</span>
                    <span class="esb-detail-value"><?php echo esc_html( $details['email'] ); ?></span>
                </div>
                <div class="esb-detail-row">
                    <span class="esb-detail-label">Nível de Surf</span>
                    <span class="esb-detail-value"><?php echo esc_html( $details['level'] ); ?></span>
                </div>
                <div class="esb-detail-row">
                    <span class="esb-detail-label">Data e Hora</span>
                    <span class="esb-detail-value">
                        <?php echo esc_html( $details['date'] ); ?> @ <?php echo esc_html( $details['time'] ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>
        
        <a href="<?php echo esc_url( home_url() ); ?>" class="esb-btn-back">
            Ir para Ericeira Local Surf
        </a>
    </div>

</body>
</html>
