<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Pedido de Aula de Surf</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased;">
    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #f1f5f9; padding: 40px 20px;">
        <tr>
            <td align="center">
                <!-- Email Card -->
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
                    <!-- Wave Accent Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%); padding: 30px 40px; text-align: center;">
                            <h1 style="color: #ffffff; font-size: 24px; font-weight: 800; margin: 0; letter-spacing: -0.02em;">🌊 Novo Pedido de Reserva</h1>
                            <p style="color: #e0f2fe; font-size: 14px; margin: 8px 0 0 0;">Ericeira Local Surf School</p>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px;">
                            <p style="font-size: 16px; color: #334155; margin-top: 0; margin-bottom: 24px; line-height: 1.5;">
                                Olá Instrutor,<br><br>
                                Foi submetido um novo pedido de marcação de aula de surf. Por favor, verifique os detalhes abaixo:
                            </p>
                            
                            <!-- Customer Details Table -->
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom: 30px; border-collapse: collapse;">
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; font-weight: 600; color: #64748b; width: 140px;">Nome do Cliente:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 15px; font-weight: 700; color: #0f172a;"><?php echo esc_html( $name ); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; font-weight: 600; color: #64748b;">E-mail do Cliente:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 15px; font-weight: 700; color: #0ea5e9;">
                                        <!-- Clickable and highly visible customer email -->
                                        <a href="mailto:<?php echo esc_attr( $email ); ?>" style="color: #0ea5e9; text-decoration: none; border-bottom: 1px dashed #0ea5e9;"><?php echo esc_html( $email ); ?></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; font-weight: 600; color: #64748b;">Nº de Telefone:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 15px; font-weight: 600; color: #0f172a;"><?php echo esc_html( $phone ? $phone : 'Não fornecido' ); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; font-weight: 600; color: #64748b;">Nível de Surf:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 15px; font-weight: 600; color: #0f172a;"><?php echo esc_html( $level ); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; font-weight: 600; color: #64748b;">Data da Aula:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 15px; font-weight: 700; color: #0f172a;"><?php echo esc_html( $date ); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; font-weight: 600; color: #64748b;">Hora da Aula:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 15px; font-weight: 700; color: #0f172a;"><?php echo esc_html( $time ); ?></td>
                                </tr>
                                <?php if ( ! empty( $comments ) ) : ?>
                                <tr>
                                    <td valign="top" style="padding: 10px 0; font-size: 14px; font-weight: 600; color: #64748b; line-height: 1.5;">Comentários:</td>
                                    <td style="padding: 10px 0; font-size: 14px; color: #334155; line-height: 1.5; font-style: italic;">"<?php echo esc_html( $comments ); ?>"</td>
                                </tr>
                                <?php endif; ?>
                            </table>
                            
                            <!-- Action Block -->
                            <p style="font-size: 15px; font-weight: 600; color: #1e293b; margin: 30px 0 15px 0; text-align: center;">
                                Decida sobre esta reserva de imediato:
                            </p>
                            
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                <tr>
                                    <!-- Approve Button -->
                                    <td width="48%" align="center">
                                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate;">
                                            <tr>
                                                <td align="center" style="border-radius: 8px; background-color: #10b981;">
                                                    <a href="<?php echo esc_url( $approve_url ); ?>" target="_blank" style="display: inline-block; padding: 14px 24px; font-size: 15px; font-weight: 700; color: #ffffff; text-decoration: none; border-radius: 8px;">
                                                        👍 Aprovar Aula
                                                    </a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    
                                    <!-- Spacer -->
                                    <td width="4%"></td>
                                    
                                    <!-- Reject Button -->
                                    <td width="48%" align="center">
                                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate;">
                                            <tr>
                                                <td align="center" style="border-radius: 8px; background-color: #f43f5e;">
                                                    <a href="<?php echo esc_url( $reject_url ); ?>" target="_blank" style="display: inline-block; padding: 14px 24px; font-size: 15px; font-weight: 700; color: #ffffff; text-decoration: none; border-radius: 8px;">
                                                        👎 Recusar Aula
                                                    </a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f8fafc; padding: 20px 40px; text-align: center; border-top: 1px solid #f1f5f9;">
                            <p style="font-size: 12px; color: #94a3b8; margin: 0;">
                                Este pedido foi enviado automaticamente a partir de <a href="https://ericeiralocalsurf.com/" style="color: #64748b; text-decoration: underline;">ericeiralocalsurf.com</a>.<br>
                                Por favor, não responda diretamente a este e-mail de notificação.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
