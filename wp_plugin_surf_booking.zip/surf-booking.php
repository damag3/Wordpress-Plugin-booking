<?php
/**
 * Plugin Name: Ericeira Local Surf Booking
 * Plugin URI: https://ericeiralocalsurf.com/
 * Description: A premium booking system for surf lessons with email notifications and one-click email approvals.
 * Version: 1.0.0
 * Author: Antigravity AI
 * License: GPL2
 * Text Domain: ericeira-surf-booking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define Constants
define( 'SURF_BOOKING_VERSION', '1.0.0' );
define( 'SURF_BOOKING_PATH', plugin_dir_path( __FILE__ ) );
define( 'SURF_BOOKING_URL', plugin_dir_url( __FILE__ ) );

// Autoload/Include Core Files
require_once SURF_BOOKING_PATH . 'includes/class-surf-booking-cpt.php';
require_once SURF_BOOKING_PATH . 'includes/class-surf-booking-settings.php';
require_once SURF_BOOKING_PATH . 'includes/class-surf-booking-form.php';
require_once SURF_BOOKING_PATH . 'includes/class-surf-booking-handler.php';
require_once SURF_BOOKING_PATH . 'includes/class-surf-booking-api.php';

/**
 * Main Plugin Class
 */
class Ericeira_Surf_Booking {
    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        // Run on plugin activation
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        
        // Initialize components
        add_action( 'plugins_loaded', array( $this, 'init' ) );
    }

    /**
     * Activation logic.
     */
    public function activate() {
        // Trigger CPT registration to flush rewrite rules
        $cpt = new Surf_Booking_CPT();
        $cpt->register_cpt();
        flush_rewrite_rules();

        // Set default settings
        if ( ! get_option( 'surf_booking_instructor_email' ) ) {
            update_option( 'surf_booking_instructor_email', 'ericeiralocal@gmail.com' );
        }
    }

    /**
     * Initialize core components after plugins are loaded.
     */
    public function init() {
        // Initialize classes
        Surf_Booking_CPT::get_instance();
        Surf_Booking_Settings::get_instance();
        Surf_Booking_Form::get_instance();
        Surf_Booking_Handler::get_instance();
        Surf_Booking_API::get_instance();
    }
}

// Instantiate the plugin
Ericeira_Surf_Booking::get_instance();
