/**
 * Ericeira Local Surf Booking - Frontend JS Handler
 */
jQuery(document).ready(function($) {
    var $form = $('#esb-booking-form');
    if (!$form.length) return;

    var $submitBtn = $('#esb-submit-btn');
    var $btnText = $submitBtn.find('.btn-text');
    var $btnLoader = $submitBtn.find('.btn-loader');
    var $feedback = $('#esb-feedback');

    // Simple automatic phone space formatting (optional UX benefit)
    $('#sb_phone').on('input', function() {
        var val = $(this).val().replace(/\D/g, '');
        if (val.length > 9) {
            val = val.substring(0, 9);
        }
        var formatted = '';
        if (val.length > 0) {
            formatted += val.substring(0, 3);
        }
        if (val.length > 3) {
            formatted += ' ' + val.substring(3, 6);
        }
        if (val.length > 6) {
            formatted += ' ' + val.substring(6, 9);
        }
        $(this).val(formatted);
    });

    // Handle Form Submit
    $form.on('submit', function(e) {
        e.preventDefault();

        // Clear previous feedback
        $feedback.addClass('esb-hidden')
                 .removeClass('esb-success esb-error')
                 .html('');

        // Basic validation check
        var name = $('#sb_name').val().trim();
        var email = $('#sb_email').val().trim();
        var level = $('#sb_surf_level').val();
        var date = $('#sb_date').val();
        var time = $('#sb_time').val();

        if (!name || !email || !level || !date || !time) {
            showFeedback('Please fill in all required fields.', 'error');
            return;
        }

        // Prepare data
        var countryCode = $('#sb_country_code').val();
        var phoneNum = $('#sb_phone').val().trim();
        var fullPhone = phoneNum ? countryCode + ' ' + phoneNum : '';

        var formData = {
            action: 'submit_surf_booking',
            security: surfBookingAjax.nonce,
            name: name,
            email: email,
            phone: fullPhone,
            level: level,
            date: date,
            time: time,
            comments: $('#sb_comments').val().trim()
        };

        // UI Loading state
        setLoading(true);

        // AJAX Request
        $.ajax({
            url: surfBookingAjax.ajaxurl,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                setLoading(false);
                if (response.success) {
                    showFeedback(response.data.message, 'success');
                    $form[0].reset();
                } else {
                    showFeedback(response.data.message || 'An error occurred. Please try again.', 'error');
                }
            },
            error: function(xhr, status, error) {
                setLoading(false);
                showFeedback('Network error. Please try again later.', 'error');
                console.error('AJAX Error:', error);
            }
        });
    });

    // UI Helper Functions
    function setLoading(isLoading) {
        if (isLoading) {
            $submitBtn.prop('disabled', true);
            $btnText.css('opacity', '0.5');
            $btnLoader.removeClass('esb-hidden');
        } else {
            $submitBtn.prop('disabled', false);
            $btnText.css('opacity', '1');
            $btnLoader.addClass('esb-hidden');
        }
    }

    function showFeedback(message, type) {
        $feedback.removeClass('esb-hidden');
        if (type === 'success') {
            $feedback.addClass('esb-success').html(message);
        } else {
            $feedback.addClass('esb-error').html(message);
        }
        
        // Scroll feedback into view if not visible
        var feedbackOffset = $feedback.offset().top;
        var windowScroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        
        if (feedbackOffset < windowScroll || feedbackOffset > (windowScroll + windowHeight)) {
            $('html, body').animate({
                scrollTop: $feedback.offset().top - 150
            }, 300);
        }
    }
});
